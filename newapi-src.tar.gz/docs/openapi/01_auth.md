# 鉴权体系详解（APP 对接核心）

> 源码：`middleware/auth.go` + `service/auth_session.go` + `service/auth_token.go` + `docs/authentication.md`

## 1. 三种凭证对照

| 凭证 | 形式 | 存储 | 有效期 | 用途 | APP 场景 |
|---|---|---|---|---|---|
| **Access Token** | JWT (HS256) | 浏览器内存/APP 内存 | **15 分钟** | 调 `/api/*` 管理接口 | ✅ 登录后短期持有 |
| **Refresh Token** | 随机串 `sid.secret` | HttpOnly Cookie | 最长 **30 天** | 换新 Access Token | ❌ 浏览器专用，APP 不适合 |
| **PAT (面板)** | 不透明密钥 `users.access_token` | DB | **永久** | 调 `/api/*`，兼容 Bearer | ✅ **APP 推荐用这个** |
| **API Key (sk-)** | 不透明密钥 | DB（令牌表） | 自设/永不过期 | 调 `/v1/*` AI 中继 | ✅ 调用模型时用 |

## 2. 关键概念

### 2.1 三级用户角色

```go
// common/constants.go（角色常量）
RoleGuestUser  = 0   // 游客
RoleCommonUser = 1   // 普通用户
RoleAdminUser  = 10  // 管理员
RoleRootUser   = 100 // 超级管理员
```

中间件 `UserAuth()` / `AdminAuth()` / `RootAuth()` 分别检查 `user.Role >= 阈值`。

### 2.2 细粒度权限（新版）

`authz.Capabilities(userId, role)` 返回 `admin_permissions` map。某些渠道/操作有 `ChannelRead / ChannelWrite / ChannelOperate / ChannelSensitiveWrite` 四级。例：

- `GET /api/channel/` 需 `ChannelRead`
- `POST /api/channel/` 需 `ChannelSensitiveWrite`（添加渠道含密钥，敏感）
- `POST /api/channel/{id}/key` 需 `RootAuth + SecureVerification` 才能查看明文

### 2.3 Security Proof（敏感操作二次验证）

5 分钟有效期的 JWT，绑定 user + session + scope。**只有"浏览器会话登录"才能获取，PAT 无法获取。**

**适用场景（来自代码）：**
- `channel.key.read`：查看渠道明文密钥
- `passkey.register`：注册 Passkey
- `passkey.delete`：删除 Passkey

**APP 替代方案**：PAT 是 root 级，不能直接拿密钥明文。如需查看渠道密钥，APP 必须**先通过 web 流程在浏览器中确认一次**，或者只用 PAT 调非敏感接口（添加/删除/启停等）。

## 3. APP 登录完整流程（推荐）

```kotlin
// 伪代码（Kotlin + Retrofit）
suspend fun login(baseUrl: String, username: String, password: String): Session {
    val resp = api.post("/api/user/login", LoginReq(username, password))
    val accessToken = resp.data.access_token
    val userId = resp.data.user.id

    // 立即换长期 PAT（如果用户允许管理）
    val patResp = api.get("/api/user/token", bearer = accessToken)
    val pat = patResp.data  // 永久的 sk-... 类似的不透明串

    return Session(baseUrl, accessToken, pat, userId)
}
```

**关键点：**
1. `POST /api/user/login` 必须 `Content-Type: application/json`
2. 若站点开了 `PASSWORD_LOGIN_ENCRYPTION_ENABLED=true`，**需要先** `GET /api/user/login/encryption-key` 拿 RSA 公钥 → 客户端加密密码 → 提交 `password_encrypted` + `encryption_key_id`
3. 若用户开了 2FA，第一次 login 返回 `data.require_2fa=true` + `flow_token` → 再调 `POST /api/user/login/2fa` 带 TOTP 码
4. 登录成功后，服务器同时种下 `new_api_refresh` HttpOnly Cookie，APP 直接忽略这个 Cookie（用不到）

## 4. Refresh / Logout（APP 场景说明）

- `POST /api/user/auth/refresh`：依赖 Refresh Cookie，**APP 不能用**
- `POST /api/user/auth/logout`：可带 Bearer，会撤销该登录会话
- **APP 登出推荐做法**：直接丢弃本地存的 token，不调后端（PAT 是永久的，丢 local 副本就等于登出）
- 如果要主动撤销某设备：APP 可以展示「查看登录会话」`GET /api/user/sessions`，让用户点「撤销」（需要 Access Token 鉴权，所以 APP 登录时拿到的 access_token 别丢，留个 15 分钟内的备用）

## 5. 中继接口鉴权（AI 调用）

`/v1/*` 系列接口是**AI 模型调用**接口，与管理接口鉴权方式不同。

**Token 解析顺序（`middleware/auth.go::TokenAuth`）：**

```
1. Sec-WebSocket-Protocol: openai-insecure-api-key.sk-xxx (WebSocket)
2. x-api-key: sk-xxx (Anthropic 兼容)
3. ?key=sk-xxx (Gemini URL 模式)
4. x-goog-api-key: sk-xxx (Gemini Header 模式)
5. Authorization: Bearer sk-xxx (标准 OpenAI 模式)
```

**所有模式最终都被规范化为 Bearer**，然后从 `users_tokens` 表查 key（**注意：API Key 在系统里是"令牌" `Token` 表，不在 users 表**）。校验通过后绑定 user context，进入中继流程。

**Key 格式约定**（代码注释）：
- 完整格式：`sk-xxx-yyy-zzz`
- 取 `parts[0]` 作实际 key（即第一个 `-` 前缀后的部分）

## 6. 错误码对照（鉴权相关）

| HTTP | code | 含义 |
|---|---|---|
| 401 | `AUTH_UNAUTHORIZED` | Token 无效/过期 |
| 401 | `AUTH_TOKEN_EXPIRED` | Access Token 过期 |
| 401 | `AUTH_SESSION_REVOKED` | 会话被撤销（密码修改等） |
| 403 | `AUTH_INSUFFICIENT_PRIVILEGE` | 角色不够 |
| 403 | `AUTH_USER_DISABLED` | 用户被封 |
| 403 | `AUTH_SESSION_REQUIRED` | 需浏览器会话（PAT 无法调用） |
| 409 | `AUTH_SESSION_LIMIT` | 单用户活跃会话超限（默认 50） |
| 409 | `AUTH_SESSION_MISMATCH` | X-Auth-Session 与 Cookie SID 不一致 |
| 409 | `AUTH_REFRESH_RACE` | Refresh 并发竞争 |
| 429 | `AUTH_SESSION_ISSUANCE_LIMIT` | 签发窗口内超限（默认 100/24h） |

## 7. APP 实战建议

1. **不要尝试用 PAT 调需要浏览器的接口**（会话管理、Security Proof）。这类操作直接引导用户去 Web 端。
2. **access_token 15 分钟过期**：APP 可起一个定时器，过期前 1 分钟用 access_token 调一个轻量接口（如 `GET /api/user/self`）测试是否还可用；失效则重新走 login 流程。
3. **更优雅的方案**：让用户输入"长期 PAT"而非用户名密码。APP 增加一个"输入 PAT 登录"入口，用户去 Web 端 `/api/user/token` 复制后填入。这种方式对 2FA 用户也最简单。
4. **不要保存 Refresh Token**：APP 场景下 Refresh Token 依赖浏览器 Cookie，存了也没用。直接用 PAT 就好。
5. **统一响应格式**（已确认）：
   ```json
   { "success": true, "message": "", "data": {...} }   // 成功
   { "success": false, "code": "...", "message": "..." } // 失败
   ```
6. **i18n**：通过 `Accept-Language` 头控制（`zh-CN` / `en` / `fr` / `ja` / `ru`）。APP 可让用户选语言。