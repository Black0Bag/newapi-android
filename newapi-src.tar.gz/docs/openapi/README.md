# New API 接口文档总览（APP 对接专用）

> 仓库：github.com/QuantumNous/new-api (v1.0.0-rc.28)
> 完整源码：当前工作区 `newapi-src/`
> 原始 OpenAPI：`docs/openapi/api.json`（136 个后台接口）+ `docs/openapi/relay.json`（35 个 AI 调用接口）

## 文档目录

| # | 文档 | 内容 |
|---|------|------|
| 0 | [README.md](./README.md)（本文件） | 索引 + 项目架构 + 鉴权体系总览 |
| 1 | [01_auth.md](./01_auth.md) | 鉴权体系详解（登录、2FA、PAT、Refresh、Security Proof） |
| 2 | [02_admin_api.md](./02_admin_api.md) | 后台管理接口全表（按业务模块分类） |
| 3 | [03_relay_api.md](./03_relay_api.md) | AI 中继/调用接口（OpenAI/Claude/Gemini 等兼容格式） |
| 4 | [04_deploy_embedded.md](./04_deploy_embedded.md) | APP 内嵌 New API 二进制：构建方案 + 进程管理 + 部署参数 |
| 5 | [05_app_design.md](./05_app_design.md) | 安卓 APP 架构建议 + 关键决策点 |
| 6 | [API_SUMMARY.txt](./API_SUMMARY.txt) | 纯文本：所有 136+35 个接口的 [方法 路径 简介] 速查表 |

## 核心结论

1. **接口总规模：171 个**（后台 136 + AI 调用 35），官方已提供 OpenAPI 规范 `api.json` + `relay.json` 可直接喂给代码生成器（如 openapi-generator）生成 Kotlin/Java Retrofit 接口。

2. **APP 鉴权推荐方案**（无需处理 Refresh Cookie 复杂性）：
   - 步骤 1：调 `POST /api/user/login` 拿 `access_token`（15 分钟）+ `user.id`
   - 步骤 2：调 `GET /api/user/token` 生成 PAT（永久 `users.access_token` 字段）
   - 步骤 3：之后所有管理接口统一用 `Authorization: Bearer <PAT>`
   - PAT 是官方明确支持的调用方式（`docs/authentication.md` §PAT 调用契约）

3. **APP 内嵌二进制方案**：项目自带 `electron/` 桌面端模板，演示了「spawn 进程 + 设置 PORT/SQLITE_PATH + 健康检查 + 优雅关停」的完整模式。移植到安卓只需做这些改动：
   - 把 `new-api` Linux amd64 二进制打进 `assets/`（或首次启动下载）
   - 用 `ProcessBuilder`（Java/Kotlin）替代 Electron 的 `spawn` 启动
   - 用 Android 端口 `127.0.0.1:&lt;动态端口&gt;` 替代 Electron 的 `127.0.0.1:3000`
   - 用 `SharedPreferences`/文件存数据库路径 `SQLITE_PATH`

## 项目基础信息（实测）

- **默认端口**：`--port 3000` / `PORT` 环境变量
- **数据目录**：`./data`（容器内），默认 SQLite 路径 `one-api.db`，可由 `SQLITE_PATH` 覆盖
- **必备环境变量**：`SESSION_SECRET`（生产必须随机值，否则启动直接 Fatal）
- **可选环境变量**：`SQL_DSN`（MySQL/PG）、`REDIS_CONN_STRING`、`SYNC_FREQUENCY` 等（详见 `common/init.go`）
- **单文件 embed 前端**：`//go:embed web/dist` + `//go:embed web/dist/index.html`
- **数据库默认**：SQLite；推荐生产用 MySQL/PostgreSQL（远程多节点场景）

## 鉴权体系速览（详见 01_auth.md）

```
┌──────────────────────────────────────────────────────────┐
│  管理接口 /api/*                                          │
│  鉴权头: Authorization: Bearer &lt;PAT 或 AccessToken&gt;        │
│  权限分三级: UserAuth / AdminAuth / RootAuth + 细粒度权限 │
└──────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────┐
│  AI 中继接口 /v1/* /v1beta/*                              │
│  鉴权头: Authorization: Bearer sk-xxx (API Key)          │
│  兼容模式: x-api-key (Anthropic), x-goog-api-key (Gemini)│
└──────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────┐
│  特殊: Security Proof X-Security-Proof                    │
│  场景: 查看渠道密钥/注册 Passkey 等敏感操作               │
│  获取: POST /api/verify  → 返回 5 分钟有效 JWT           │
└──────────────────────────────────────────────────────────┘
```
