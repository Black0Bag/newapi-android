# 后台管理 API 全表（按业务模块分类）

> 来源：`docs/openapi/api.json`（136 个路径，含方法 161 个）
> 路由注册：`router/api-router.go` + `router/channel-router.go`
> 本表只列接口和用途，鉴权等级看 README/01_auth.md

## 1. 系统初始化与状态（23 个）

| 方法 | 路径 | 说明 | 鉴权 |
|---|---|---|---|
| GET | `/api/setup` | 获取初始化状态 | 匿名 |
| POST | `/api/setup` | 初始化系统 | 匿名 |
| GET | `/api/status` | 获取系统状态 | 匿名 |
| GET | `/api/status/test` | 测试系统状态 | AdminAuth |
| GET | `/api/uptime/status` | 获取Uptime Kuma状态 | 匿名 |
| GET | `/api/notice` | 获取公告 | 匿名 |
| GET | `/api/user-agreement` | 获取用户协议 | 匿名 |
| GET | `/api/privacy-policy` | 获取隐私政策 | 匿名 |
| GET | `/api/about` | 获取关于信息 | 匿名 |
| GET | `/api/home_page_content` | 获取首页内容 | 匿名 |
| GET | `/api/pricing` | 获取定价信息 | HeaderNavModuleAuth |
| GET | `/api/models` | 获取模型列表（用户可见） | UserAuth |
| GET | `/api/ratio_config` | 获取倍率配置 | CriticalRateLimit |
| GET | `/api/verification` | 发送邮箱验证码 | EmailRateLimit+Turnstile |
| GET | `/api/reset_password` | 发送密码重置邮件 | CriticalRateLimit |
| GET | `/api/models/` | 获取所有模型元数据 | AdminAuth |
| POST | `/api/models/` | 创建模型元数据 | AdminAuth |
| PUT | `/api/models/` | 更新模型元数据 | AdminAuth |
| GET | `/api/models/search` | 搜索模型 | AdminAuth |
| GET | `/api/models/{id}` | 获取指定模型 | AdminAuth |
| DELETE | `/api/models/{id}` | 删除模型 | AdminAuth |
| GET | `/api/models/sync_upstream/preview` | 预览上游模型同步 | AdminAuth |
| POST | `/api/models/sync_upstream` | 同步上游模型 | AdminAuth |
| GET | `/api/models/missing` | 获取缺失模型 | AdminAuth |

## 2. 用户与认证（9 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/user/login` | 用户登录（密码/2FA/Passkey） |
| POST | `/api/user/login/2fa` | 两步验证登录 |
| POST | `/api/user/register` | 用户注册 |
| POST | `/api/user/reset` | 重置密码 |
| POST | `/api/user/auth/refresh` | 刷新面板登录（Cookie） |
| POST | `/api/user/auth/logout` | 撤销当前登录会话 |
| GET | `/api/user/sessions` | 查看登录会话 |
| DELETE | `/api/user/sessions/{sid}` | 撤销指定登录会话 |
| POST | `/api/user/sessions/revoke-others` | 撤销其他登录会话 |

## 3. 个人中心 / 2FA / Passkey（26 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/user/self` | 获取当前用户信息 |
| PUT | `/api/user/self` | 更新当前用户信息 |
| DELETE | `/api/user/self` | 注销当前用户 |
| GET | `/api/user/self/groups` | 获取当前用户分组 |
| GET | `/api/user/groups` | 获取用户分组列表（公开） |
| GET | `/api/user/models` | 获取用户可用模型 |
| GET | `/api/user/token` | **生成访问令牌（PAT）** |
| GET | `/api/user/aff` | 获取邀请码 |
| POST | `/api/user/aff_transfer` | 转换邀请额度 |
| PUT | `/api/user/setting` | 更新用户设置 |
| GET | `/api/user/2fa/status` | 获取2FA状态 |
| POST | `/api/user/2fa/setup` | 设置2FA |
| POST | `/api/user/2fa/enable` | 启用2FA |
| POST | `/api/user/2fa/disable` | 禁用2FA |
| POST | `/api/user/2fa/backup_codes` | 重新生成备用码 |
| GET | `/api/user/2fa/stats` | 获取2FA统计（Admin） |
| DELETE | `/api/user/{id}/2fa` | 管理员禁用用户2FA |
| GET | `/api/user/passkey` | 获取Passkey状态 |
| POST | `/api/user/passkey/register/begin` | 开始注册Passkey |
| POST | `/api/user/passkey/register/finish` | 完成注册Passkey |
| POST | `/api/user/passkey/verify/begin` | 开始验证Passkey |
| POST | `/api/user/passkey/verify/finish` | 完成验证Passkey |
| POST | `/api/user/passkey/login/begin` | 开始Passkey登录 |
| POST | `/api/user/passkey/login/finish` | 完成Passkey登录 |
| DELETE | `/api/user/passkey` | 删除Passkey |
| DELETE | `/api/user/{id}/reset_passkey` | 管理员重置用户Passkey |

## 4. OAuth 第三方登录（11 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/oauth/github` | GitHub OAuth登录 |
| GET | `/api/oauth/discord` | Discord OAuth登录 |
| GET | `/api/oauth/oidc` | OIDC登录 |
| GET | `/api/oauth/linuxdo` | LinuxDO OAuth登录 |
| GET | `/api/oauth/wechat` | 微信OAuth登录 |
| POST | `/api/oauth/wechat/bind` | 绑定微信 |
| POST | `/api/oauth/email/bind` | 绑定邮箱 |
| GET | `/api/oauth/telegram/login` | Telegram登录 |
| POST | `/api/oauth/telegram/bind/start` | 创建 Telegram 绑定流程 |
| GET | `/api/oauth/telegram/bind/{flow_token}` | 完成 Telegram 绑定 |
| POST | `/api/oauth/state` | 生成OAuth State |

## 5. 充值与支付（12 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/user/topup/info` | 获取充值信息（套餐、支付方式） |
| GET | `/api/user/topup/self` | 获取个人充值记录 |
| GET | `/api/user/topup` | 获取所有充值记录（Admin） |
| POST | `/api/user/topup/complete` | 管理员手动完成充值 |
| POST | `/api/user/pay` | 发起易支付 |
| POST | `/api/user/amount` | 获取支付金额 |
| POST | `/api/user/stripe/pay` | 发起Stripe支付 |
| POST | `/api/user/stripe/amount` | 获取Stripe支付金额 |
| POST | `/api/user/creem/pay` | 发起Creem支付 |
| GET | `/api/user/epay/notify` | 易支付回调（GET 形式） |
| POST | `/api/stripe/webhook` | Stripe Webhook |
| POST | `/api/creem/webhook` | Creem Webhook |

## 6. 用户管理 Admin（7 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/user/` | 获取所有用户（分页、排序） |
| POST | `/api/user/` | 创建用户 |
| PUT | `/api/user/` | 更新用户 |
| POST | `/api/user/manage` | 管理用户状态（启停/升降/加减额度） |
| GET | `/api/user/search` | 搜索用户 |
| GET | `/api/user/{id}` | 获取指定用户 |
| DELETE | `/api/user/{id}` | 删除用户 |

## 7. 渠道 Channel 管理（25 个）—— **最复杂**

> 全部 AdminAuth，操作分 ChannelRead/Write/Operate/SensitiveWrite 四级

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/channel/` | 获取所有渠道（分页） |
| POST | `/api/channel/` | 添加渠道（敏感） |
| PUT | `/api/channel/` | 更新渠道 |
| DELETE | `/api/channel/{id}` | 删除渠道（敏感） |
| GET | `/api/channel/{id}` | 获取指定渠道 |
| GET | `/api/channel/search` | 搜索渠道 |
| GET | `/api/channel/models` | 获取渠道模型列表 |
| GET | `/api/channel/models_enabled` | 获取已启用模型列表 |
| POST | `/api/channel/{id}/key` | **获取明文密钥（RootAuth + SecureVerification）** |
| GET | `/api/channel/test` | 测试所有渠道 |
| GET | `/api/channel/test/{id}` | 测试指定渠道 |
| GET | `/api/channel/update_balance` | 更新所有渠道余额 |
| GET | `/api/channel/update_balance/{id}` | 更新指定渠道余额 |
| DELETE | `/api/channel/disabled` | 删除已禁用渠道（敏感） |
| POST | `/api/channel/batch` | 批量删除渠道（敏感） |
| POST | `/api/channel/fix` | 修复渠道能力 |
| GET | `/api/channel/fetch_models/{id}` | 获取上游模型列表 |
| POST | `/api/channel/fetch_models` | 获取模型列表（敏感） |
| GET | `/api/channel/tag/models` | 获取标签模型 |
| POST | `/api/channel/tag/disabled` | 禁用标签渠道 |
| POST | `/api/channel/tag/enabled` | 启用标签渠道 |
| PUT | `/api/channel/tag` | 编辑标签渠道 |
| POST | `/api/channel/batch/tag` | 批量设置渠道标签 |
| POST | `/api/channel/copy/{id}` | 复制渠道（敏感） |
| POST | `/api/channel/multi_key/manage` | 管理多密钥（轮换） |

## 8. 令牌 Token 管理（7 个）

> 用户的 API Key（sk-xxx），是 `/v1/*` AI 调用的凭据

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/token/` | 获取所有令牌 |
| POST | `/api/token/` | 创建令牌 |
| PUT | `/api/token/` | 更新令牌 |
| GET | `/api/token/search` | 搜索令牌 |
| GET | `/api/token/{id}` | 获取指定令牌 |
| DELETE | `/api/token/{id}` | 删除令牌 |
| POST | `/api/token/batch` | 批量删除令牌 |

## 9. 兑换码 Redemption（7 个，AdminAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/redemption/` | 获取所有兑换码 |
| POST | `/api/redemption/` | 创建兑换码（生成多个） |
| PUT | `/api/redemption/` | 更新兑换码 |
| GET | `/api/redemption/search` | 搜索兑换码 |
| GET | `/api/redemption/{id}` | 获取指定兑换码 |
| DELETE | `/api/redemption/{id}` | 删除兑换码 |
| DELETE | `/api/redemption/invalid` | 删除无效兑换码 |

## 10. 日志与统计（10 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/log/` | 获取所有日志（Admin） |
| GET | `/api/log/stat` | 获取日志统计（Admin） |
| GET | `/api/log/search` | 搜索日志（Admin） |
| GET | `/api/log/self` | 获取个人日志 |
| GET | `/api/log/self/stat` | 获取个人日志统计 |
| GET | `/api/log/self/search` | 搜索个人日志 |
| GET | `/api/log/token` | 通过令牌获取日志（TokenAuthReadOnly） |
| GET | `/api/usage/token/` | 获取令牌使用情况（TokenAuthReadOnly） |
| GET | `/api/data/` | 获取所有额度数据（Admin） |
| GET | `/api/data/self` | 获取个人额度数据 |

## 11. Midjourney / 任务（4 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/mj/` | 获取所有Midjourney任务（Admin） |
| GET | `/api/mj/self` | 获取个人Midjourney任务 |
| GET | `/api/task/` | 获取所有任务（Admin） |
| GET | `/api/task/self` | 获取个人任务 |

## 12. 系统设置 Option（3 个，RootAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/option/` | 获取系统选项 |
| PUT | `/api/option/` | 更新系统选项 |
| POST | `/api/option/rest_model_ratio` | 重置模型倍率 |

> 实际还有 30+ 隐藏子接口（option/payment_compliance、option/channel_affinity_cache 等），详见 `router/api-router.go`。

## 13. 供应商 Vendor（6 个，AdminAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/vendors/` | 获取所有供应商 |
| POST | `/api/vendors/` | 创建供应商 |
| PUT | `/api/vendors/` | 更新供应商 |
| GET | `/api/vendors/search` | 搜索供应商 |
| GET | `/api/vendors/{id}` | 获取指定供应商 |
| DELETE | `/api/vendors/{id}` | 删除供应商 |

## 14. 预填分组 Prefill Group（5 个，AdminAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/prefill_group/` | 获取预填分组 |
| POST | `/api/prefill_group/` | 创建预填分组 |
| PUT | `/api/prefill_group/` | 更新预填分组 |
| DELETE | `/api/prefill_group/{id}` | 删除预填分组 |

## 15. 倍率同步（2 个，RootAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/ratio_sync/channels` | 获取可同步渠道 |
| POST | `/api/ratio_sync/fetch` | 获取上游倍率 |

## 16. 其他

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/group/` | 获取所有分组（Admin） |
| POST | `/api/verify` | 通用安全验证（UserAuth） |
| GET | `/api/verify/status` | 获取验证状态 |
| POST | `/api/system-task/log-cleanup` | 创建日志清理任务（RootAuth） |

---

> **重要提示**：`docs/openapi/api.json` 只覆盖了 136 个路径。`router/api-router.go` 中实际还有 **订阅、自定义OAuth、authz、性能监控、部署管理、插件系统** 等大量接口未被官方 OpenAPI 收录。完整列表见 `02_admin_api_extra.md`。