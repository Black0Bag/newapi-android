# 安卓 APP 架构设计建议

> 目标：纯原生 Android UI + 内嵌 New API 二进制
> 本文档列出关键决策点和推荐方案

## 1. 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│  Android APP (Kotlin / Java)                                │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  UI 层：Activity / Fragment / Compose                  │  │
│  │  ┌─────────────┬─────────────┬─────────────┐           │  │
│  │  │  仪表盘     │  渠道管理   │  令牌管理   │  ...     │  │
│  │  └─────────────┴─────────────┴─────────────┘           │  │
│  └─────────────────────┬───────────────────────────────────┘  │
│                        │ Retrofit + OkHttp                   │
│  ┌─────────────────────▼───────────────────────────────────┐  │
│  │  服务层：API Client（基于 docs/openapi/ 文档）          │  │
│  └─────────────────────┬───────────────────────────────────┘  │
│                        │ http://127.0.0.1:13000             │
│  ┌─────────────────────▼───────────────────────────────────┐  │
│  │  进程管理层：NewApiService (Foreground Service)         │  │
│  │  - start/stop 二进制                                    │  │
│  │  - 端口健康检查                                          │  │
│  │  - 日志捕获                                             │  │
│  └─────────────────────┬───────────────────────────────────┘  │
│                        │ spawn                               │
│  ┌─────────────────────▼───────────────────────────────────┐  │
│  │  New API 二进制（Linux ARM64 ELF）                       │  │
│  │  - Gin HTTP server on 127.0.0.1:13000                   │  │
│  │  - SQLite at /data/data/com.app/files/data/new-api.db   │  │
│  │  - 监听 WebView 提供完整 Web UI                          │  │
│  └─────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 关键模块划分

### 2.1 UI 模块（建议用 Jetpack Compose）

| 屏幕 | 对应接口 |
|---|---|
| 启动页 / 引导页 | `GET /api/status` |
| 登录页 | `POST /api/user/login` 或 PAT 输入 |
| 仪表盘 | `GET /api/user/self`, `GET /api/log/self/stat` |
| 渠道列表 | `GET /api/channel/` |
| 渠道编辑 | `POST/PUT /api/channel/` |
| 令牌列表 | `GET /api/token/` |
| 兑换码 | `GET /api/redemption/` |
| 日志/统计 | `GET /api/log/self` |
| 用户管理 | `GET /api/user/` |
| 设置 | `GET /api/option/` |
| WebView（完整 Web） | `http://127.0.0.1:13000/`（用于初始化、向导、复杂操作） |

### 2.2 核心服务

```kotlin
class NewApiService : Service() {
    // 1. 启动二进制
    fun startBackend()
    // 2. 健康检查 + 自动重试
    fun ensureBackend()
    // 3. 日志流（输出到 UI 调试面板）
    fun captureLogs()
    // 4. 优雅关停
    fun stopBackend()
}
```

### 2.3 进程保活（**安卓最头疼的问题**）

| 策略 | 适用 |
|---|---|
| Foreground Service + 通知 | ✅ **必做**。系统不杀 |
| START_STICKY | ✅ 进程被杀后系统会重启 |
| WorkManager 周期唤醒 | 配合前台服务 |
| REQUEST_IGNORE_BATTERY_OPTIMIZATIONS | ✅ 必加 |
| 自启动 (BOOT_COMPLETED) | 重启后自动拉起 |
| 双进程守护 (主+辅) | 高端方案 |

## 3. 网络层设计

### 3.1 Base URL

```kotlin
object ApiConfig {
    const val BASE_URL = "http://127.0.0.1:13000"
    // 用户也可以在设置中改成远程 new-api 实例的 URL
    // 这样可以「连自己的云端 + 别人搭的实例」
}
```

**关键洞察**：用户配置 baseUrl 后，**可以连自己的远程 New API**（不是必须用本机嵌入的）。这是你这个 APP 的核心灵活性。

### 3.2 Retrofit 客户端

```kotlin
val okHttp = OkHttpClient.Builder()
    .addInterceptor { chain ->
        val req = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer ${Session.pat}")
            .addHeader("Accept-Language", Session.lang)  // i18n
            .build()
        chain.proceed(req)
    }
    .addInterceptor(HttpLoggingInterceptor().apply { 
        level = if (BuildConfig.DEBUG) BODY else NONE 
    })
    .connectTimeout(10, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .build()
```

### 3.3 错误处理

New API 三种错误格式（要兼容）：

```kotlin
// 1. 管理接口错误
{"success": false, "code": "AUTH_TOKEN_EXPIRED", "message": "..."}

// 2. AI 中继错误（OpenAI 格式）
{"error": {"message": "...", "type": "...", "code": "..."}}

// 3. 流式中断（chunk 中 error 字段）
data: {"error": {"message": "..."}}
```

## 4. 数据持久化

| 数据 | 存哪里 | 加密？ |
|---|---|---|
| 服务器 URL | DataStore / SharedPreferences | 否 |
| PAT (面板) | EncryptedSharedPreferences | **是** |
| 用户名密码 | **不存**（每次输入） | — |
| 二进制 + SQLite | `filesDir/` | 否（数据库本身可加密） |
| 会话列表缓存 | Room | 否 |

```kotlin
// EncryptedSharedPreferences 存 PAT
val prefs = EncryptedSharedPreferences.create(
    "auth",
    MasterKey.Builder(context).setKeyScheme(AES256_GCM).build(),
    context,
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)
prefs.edit().putString("pat", token).apply()
```

## 5. 关键决策点（需要你拍板）

### 决策 1：UI 用什么？

- **Jetpack Compose**（推荐）：现代、声明式、适合做仪表盘类应用
- 传统 View：成熟、案例多
- **混合**：核心屏用 Compose，复杂表格用 WebView 套 New API 自带 Web 端

### 决策 2：是否提供"连接远程实例"功能？

- **强烈建议加**：用户除了自建，也可以填别人的 New API URL
- 实现成本极低（baseUrl 改成用户输入即可）
- 极大提升 APP 适用面（"多 API 中转站统一管理"）

### 决策 3：是否内嵌 WebView？

- **强烈建议加**：用 New API 自带的 React Web 做"高级功能"入口
- 初始化向导、复杂设置、图表展示，APP 重做太累
- WebView 包成 `WebViewActivity`，给个 URL `http://127.0.0.1:13000/`

### 决策 4：是否做账号体系？

- **不需要做**：每个登录的 New API 实例是独立的
- APP 只做"配置文件管理"（多个 baseUrl + 凭据）
- 类似 PostgreSQL 客户端：连不同的库，不需要自己建库

### 决策 5：二进制打包方式

- **A. 打进 APK**（推荐首次启动快）：APK 多 30MB，但离线可用
- **B. 启动时从 GitHub 下载**（节省空间）：但要联网
- **C. 首次启动用内置 + 启动后 OTA 更新**（折中）

## 6. 开发路线图（建议 4 阶段）

### Phase 1：MVP（2-3 周）
- [ ] 二进制打包到 assets
- [ ] 启动服务 + 端口检查
- [ ] 登录页（用户名密码 + PAT 两种方式）
- [ ] 仪表盘（用户信息 + 余额 + 最近日志）
- [ ] 一个完整业务流（如：列出渠道）

### Phase 2：核心功能（4-6 周）
- [ ] 渠道增删改查
- [ ] 令牌增删改查
- [ ] 用户管理（Admin）
- [ ] 日志查询 + 筛选
- [ ] 兑换码生成
- [ ] WebView 包装

### Phase 3：高级（4 周）
- [ ] 多实例配置管理（核心卖点）
- [ ] 数据备份/恢复
- [ ] 主题/语言切换
- [ ] 通知（异常登录、低余额告警）

### Phase 4：打磨（持续）
- [ ] 性能优化
- [ ] 二进制 OTA 更新
- [ ] 错误诊断（参考 electron/main.js 的 analyzeError）

## 7. 必备权限

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>
```

## 8. 调试技巧

- **APP 内调试面板**：实时显示二进制 stdout/stderr（参考 `electron/main.js` 的 `serverErrorLogs`）
- **端口扫描**：`/proc/net/tcp` 看监听端口
- **日志路径**：APP 内部调试可以读 `data/logs/`
- **导出日志**：UI 提供"导出日志"按钮（zip 打包）

## 9. 你的"统一管理"特性（差异化亮点）

这是你 APP 与 piexian/newapi-app 的核心区别。**piexian 那个只连一个 New API 实例**；你的可以：

- 一次添加多个 New API 实例（本地自建 + 别人搭的）
- 总览面板：所有实例的余额、日志告警
- 跨实例搜渠道、令牌
- 一键调用：选中 token 即可发起请求（用本地嵌入的或最优实例）
- 一键迁移：从 A 实例复制渠道配置到 B 实例

**这就是你项目立项的核心价值。**