# 后台管理 API - 补充（OpenAPI 未收录部分）

> 源码：`router/api-router.go` + `router/authz-router.go`
> 这些接口实际可用，但 `docs/openapi/api.json` 没有自动生成文档
> **APP 对接时务必查本表**

## 1. 订阅 Subscription（22 个）

> `/api/subscription/*` - UserAuth / AdminAuth
> 站内订阅/付费计划功能

### 用户侧（UserAuth）

| 方法 | 路径 |
|---|---|
| GET | `/api/subscription/plans` |
| GET | `/api/subscription/self` |
| PUT | `/api/subscription/self/preference` |
| POST | `/api/subscription/balance/pay` |
| POST | `/api/subscription/epay/pay` |
| POST | `/api/subscription/stripe/pay` |
| POST | `/api/subscription/creem/pay` |
| POST | `/api/subscription/waffo-pancake/pay` |

### 管理员侧（AdminAuth）

| 方法 | 路径 |
|---|---|
| GET | `/api/subscription/admin/plans` |
| POST | `/api/subscription/admin/plans` |
| PUT | `/api/subscription/admin/plans/{id}` |
| PATCH | `/api/subscription/admin/plans/{id}` |
| POST | `/api/subscription/admin/bind` |
| POST | `/api/subscription/admin/plans/{id}/subscriptions/reset` |
| GET | `/api/subscription/admin/users/{id}/subscriptions` |
| POST | `/api/subscription/admin/users/{id}/subscriptions` |
| POST | `/api/subscription/admin/users/{id}/subscriptions/reset` |
| POST | `/api/subscription/admin/user_subscriptions/{id}/invalidate` |
| DELETE | `/api/subscription/admin/user_subscriptions/{id}` |

### 支付回调（匿名）

| 方法 | 路径 |
|---|---|
| POST | `/api/subscription/epay/notify` |
| GET | `/api/subscription/epay/notify` |
| GET | `/api/subscription/epay/return` |
| POST | `/api/subscription/epay/return` |

## 2. 认证授权 authz（1 个，AdminAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/authz/catalog` | 获取权限目录（资源/动作/角色基线） |

## 3. 自定义 OAuth Provider（6 个，RootAuth）

| 方法 | 路径 |
|---|---|
| POST | `/api/custom-oauth-provider/discovery` |
| GET | `/api/custom-oauth-provider/` |
| GET | `/api/custom-oauth-provider/{id}` |
| POST | `/api/custom-oauth-provider/` |
| PUT | `/api/custom-oauth-provider/{id}` |
| DELETE | `/api/custom-oauth-provider/{id}` |

## 4. 性能与监控（10+ 个，RootAuth）

| 方法 | 路径 |
|---|---|
| GET | `/api/performance/stats` |
| DELETE | `/api/performance/disk_cache` |
| POST | `/api/performance/reset_stats` |
| POST | `/api/performance/gc` |
| GET | `/api/performance/logs` |
| DELETE | `/api/performance/logs` |
| GET | `/api/system-info/instances` |
| DELETE | `/api/system-info/stale-instances` |
| DELETE | `/api/system-info/instances/{node_name}` |
| GET | `/api/system-task/list` |
| GET | `/api/system-task/current` |
| GET | `/api/system-task/{task_id}` |

## 5. 部署管理 Deployments（20+ 个，AdminAuth）

> 第三方 GPU 部署（io.net），与 Channel 不同

| 方法 | 路径 |
|---|---|
| GET | `/api/deployments/settings` |
| POST | `/api/deployments/settings/test-connection` |
| GET | `/api/deployments/` |
| GET | `/api/deployments/search` |
| POST | `/api/deployments/test-connection` |
| GET | `/api/deployments/hardware-types` |
| GET | `/api/deployments/locations` |
| GET | `/api/deployments/available-replicas` |
| POST | `/api/deployments/price-estimation` |
| GET | `/api/deployments/check-name` |
| POST | `/api/deployments/` |
| GET | `/api/deployments/{id}` |
| GET | `/api/deployments/{id}/logs` |
| GET | `/api/deployments/{id}/containers` |
| GET | `/api/deployments/{id}/containers/{container_id}` |
| PUT | `/api/deployments/{id}` |
| PUT | `/api/deployments/{id}/name` |
| POST | `/api/deployments/{id}/extend` |
| DELETE | `/api/deployments/{id}` |

## 6. 插件系统（11+ 个，RootAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/plugin/task` | 列出所有任务插件 |
| POST | `/api/plugin/task` | 上传任务插件 |
| PUT | `/api/plugin/task` | 更新任务插件 |
| GET | `/api/plugin/task/runtime/status` | 任务插件运行时状态 |
| GET | `/api/plugin/task/marketplace/sources` | 插件市场源 |
| PUT | `/api/plugin/task/marketplace/sources` | 更新插件市场源 |
| GET | `/api/plugin/task/{key}` | 获取指定插件 |
| GET | `/api/plugin/task/{key}/versions` | 插件版本列表 |
| POST | `/api/plugin/task/{key}/activate` | 激活插件 |
| POST | `/api/plugin/task/{key}/status` | 设置插件状态 |
| POST | `/api/plugin/task/{key}/dryrun` | 干跑测试 |
| DELETE | `/api/plugin/task/{key}/versions/{version}` | 删除版本 |
| GET | `/api/task_plugin_options` | 任务插件选项（AdminAuth） |

## 7. 任务中心 Plugin Endpoint（动态，5+ 个）

> `router/task-plugin-protocol-router.go` 注册的动态路由

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/responses` | OpenAI Responses 格式 |
| GET | `/v1/responses/{response_id}` | 获取 Responses |
| POST | `/v1/videos` | OpenAI Video 格式 |
| GET | `/v1/videos/{video_id}` | 获取视频状态 |
| GET | `/v1/videos/{video_id}/content` | 获取视频内容 |

## 8. WebSocket 实时对话

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/v1/realtime` | OpenAI Realtime 协议 WS |

## 9. 中继/任务通用（TokenAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/tasks/{key}` | 提交任务 |
| GET | `/v1/tasks/{key}` | 获取任务状态 |
| GET | `/v1/tasks/{key}/artifacts` | 获取任务工件 |
| GET | `/v1/tasks/{key}/artifacts/{artifact_key}/content` | 获取工件内容 |
| HEAD | `/v1/tasks/{key}/artifacts/{artifact_key}/content` | 同上 HEAD 形式 |

## 10. 性能指标 PerfMetrics

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/perf-metrics` | 性能指标 |
| GET | `/api/perf-metrics/summary` | 性能指标摘要 |

## 11. 排行榜 Rankings

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/rankings` | 排行榜 |

## 12. Waffo 系列支付

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/waffo/webhook` | Waffo 回调 |
| POST | `/api/waffo-pancake/webhook/{env}` | Waffo Pancake 回调（test/prod） |
| POST | `/api/user/waffo/amount` | Waffo 支付金额（UserAuth） |
| POST | `/api/user/waffo/pay` | Waffo 支付（UserAuth） |
| POST | `/api/user/waffo-pancake/amount` | Waffo Pancake 金额（UserAuth） |
| POST | `/api/user/waffo-pancake/pay` | Waffo Pancake 支付（UserAuth） |
| GET | `/api/option/waffo-pancake/catalog` | Waffo Pancake 目录（RootAuth） |
| POST | `/api/option/waffo-pancake/pair` | Waffo Pancake 配对（RootAuth） |
| POST | `/api/option/waffo-pancake/save` | Waffo Pancake 保存（RootAuth） |
| POST | `/api/option/waffo-pancake/subscription-product` | Waffo Pancake 订阅产品（RootAuth） |
| GET | `/api/option/waffo-pancake/subscription-product-options` | Waffo Pancake 订阅产品选项（RootAuth） |

## 13. 通用 verify 端点（UserAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/verify` | 通用安全验证（需要登录） |
| GET | `/api/verify/status` | 获取验证状态 |

## 14. 总数

| 分类 | 接口数 |
|---|---|
| 后台 OpenAPI 收录 | 161 |
| 后台 OpenAPI 未收录 | 约 80+ |
| AI 中继（relay.json） | 35 |
| **总计** | **约 280+** |