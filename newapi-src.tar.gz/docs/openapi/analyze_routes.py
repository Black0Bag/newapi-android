#!/usr/bin/env python3
"""对比 api.json 与 router 源码，找出接口清单与代码的一致性。"""
import json, re, os

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(BASE))

# 1. api.json 中的路径
with open(os.path.join(BASE, 'api.json')) as f:
    d = json.load(f)
json_paths = set(d.get('paths', {}).keys())

# 2. 从 router/*.go 提取直接注册的路径片段
def extract_routes(path):
    routes = set()
    groups = []
    with open(path) as f:
        content = f.read()
    # GET("/xxx") 或 GET("/xxx",  ...
    for m in re.finditer(r'(GET|POST|PUT|DELETE|PATCH)\s*\(\s*"([^"]+)"', content):
        routes.add(m.group(2))
    for m in re.finditer(r'Group\s*\(\s*"([^"]+)"', content):
        groups.append(m.group(1))
    return routes, groups

router_files = ['api-router.go', 'channel-router.go']
all_routes = set()
all_groups = set()
for fn in router_files:
    r, g = extract_routes(os.path.join(ROOT, 'router', fn))
    all_routes |= r
    all_groups |= set(g)

print(f"api.json 路径数: {len(json_paths)}")
print(f"路由源码直接注册(含片段): {len(all_routes)} 个")
print(f"路由源码 Group 前缀: {sorted(all_groups)}")

print("\n===== api.json 中特别值得关注的新版专属接口 =====")
for p in sorted(json_paths):
    if any(k in p for k in ['subscription', 'deployments', 'system-info', 'system-task', 'authz', 'custom-oauth', 'performance', 'passkey', 'checkin', 'perf-metrics', 'rankings', 'prefill_group']):
        print(" ", p)