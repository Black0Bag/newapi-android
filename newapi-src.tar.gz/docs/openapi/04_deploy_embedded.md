# APP 内嵌 New API 二进制：构建方案 + 进程管理

> 这是你最关心的部分。官方 `electron/` 桌面端有现成的内嵌二进制方案，可以作为参考。

## 1. 项目已有的"内嵌二进制"实现（参考）

`electron/main.js` 完整演示了：
- 定位二进制路径（开发/生产）
- `spawn(binaryPath, [], { env, cwd })` 启动
- 注入环境变量 `PORT`、`SQLITE_PATH`
- 健康检查（30 次重试连 `127.0.0.1:3000`）
- 优雅关停（`SIGTERM` → 5 秒后 `SIGKILL`）
- 错误分析（端口占用、数据库锁、权限错误等）

**直接照搬思路到安卓。**

## 2. New API 单二进制构建

### 2.1 现有 Dockerfile（参考）

```dockerfile
FROM oven/bun:1.4.0 AS builder
WORKDIR /build/web
COPY web/package.json web/bun.lock ./
RUN bun install --frozen-lockfile
COPY ./web ./
RUN bun run build  # 输出到 web/dist

FROM golang:1.26.1-alpine AS builder2
WORKDIR /build
ADD go.mod go.sum ./
ADD relaykit/go.mod ./relaykit/go.mod
RUN go mod download
COPY . .
COPY --from=builder /build/web/dist ./web/dist
RUN go build -ldflags "-s -w -X '...Version=...'" -o new-api

FROM debian:bookworm-slim
COPY --from=builder2 /build/new-api /
EXPOSE 3000
WORKDIR /data
ENTRYPOINT ["/new-api"]
```

### 2.2 给安卓用的关键调整

**目标平台**：`GOOS=linux GOARCH=amd64`（在 x86 模拟器/Chromebook）或 `arm64`（真机/大多数设备）

```bash
# 1. 构建前端
cd newapi-src/web
bun install
bun run build  # 输出 web/dist

# 2. 构建 Go 二进制
cd newapi-src
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 \
  go build -ldflags "-s -w -X 'github.com/QuantumNous/new-api/common.Version=$(cat VERSION)'" \
  -o new-api-arm64
```

> **CGO_ENABLED 必须 0**，否则需要带 glibc。安卓 Bionic libc 与 glibc 不兼容。

### 2.3 二进制运行时依赖

- 仅依赖：`/etc/ssl/certs/ca-certificates.crt`（HTTPS 调用上游）
- 不需要 glibc、不需要其他 so

**安卓需要预置 CA 证书**：
```bash
# 把系统 CA 拷到 APP 私有目录
adb push /system/etc/security/cacerts/* /data/local/tmp/
```

或者直接让 Go 二进制跳过 TLS 验证（**生产不推荐**）：`TLS_INSECURE_SKIP_VERIFY=true`

## 3. APP 进程管理（关键代码模式）

### 3.1 二进制存放

```
Android/data/com.your.app/files/
  ├── new-api              # 7MB 左右的 Go 二进制
  ├── data/                # 数据库/日志目录（绑定到此处）
  │   ├── new-api.db       # SQLite
  │   └── logs/
  └── config/
      └── .env             # 启动环境变量
```

### 3.2 Kotlin 启动代码（伪代码）

```kotlin
class NewApiService {
    private var process: Process? = null
    private val port = 13000  // 选个偏门端口避免冲突

    fun start() {
        val dataDir = File(context.filesDir, "data").apply { mkdirs() }
        val binary = File(context.filesDir, "new-api")

        val cmd = listOf(
            binary.absolutePath,
            "--port", port.toString(),
            "--log-dir", File(dataDir, "logs").absolutePath
        )
        val env = mapOf(
            "SQLITE_PATH" to File(dataDir, "new-api.db").absolutePath,
            "SESSION_SECRET" to sharedPrefs.getString("session_secret", ""),
            "GIN_MODE" to "release"
        )

        process = ProcessBuilder(cmd).apply {
            directory(context.filesDir)
            environment().putAll(env)
            redirectErrorStream(true)
        }.start()

        // 启动健康检查
        CoroutineScope(Dispatchers.IO).launch {
            waitForPort(port, timeoutMs = 30_000)
        }
    }

    fun stop() {
        process?.destroy()  // SIGTERM
        Thread.sleep(3000)
        if (process?.isAlive == true) process?.destroyForcibly()  // SIGKILL
    }
}
```

### 3.3 端口选择

- 避免使用系统保留端口（< 1024）
- 避免使用其他常用端口（3000、5000、8000、8080）
- **推荐 13000~13500 之间的随机端口**，避免与其他 APP 冲突
- 用 `127.0.0.1:&lt;port&gt;` 访问，APP 内 WebView 走 `http://127.0.0.1:&lt;port&gt;`

### 3.4 健康检查

```kotlin
suspend fun waitForPort(port: Int, timeoutMs: Long) {
    val deadline = System.currentTimeMillis() + timeoutMs
    val url = URL("http://127.0.0.1:$port/api/status")
    while (System.currentTimeMillis() < deadline) {
        try {
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.readTimeout = 2000
            if (conn.responseCode in 200..299) return  // 成功
        } catch (e: Exception) {
            // 还没就绪
        }
        delay(1000)
    }
    throw TimeoutException("new-api 启动超时")
}
```

## 4. 部署环境变量（必看）

| 变量 | 必填？ | 默认 | 说明 |
|---|---|---|---|
| `PORT` | 否 | 3000 | 监听端口 |
| `SQLITE_PATH` | 否 | one-api.db | 数据库路径（**APP 必填**，指向 `files/data/`） |
| `SESSION_SECRET` | **生产必填** | 随机 UUID | JWT 签名密钥。**设默认值会 Fatal** |
| `LOG_DIR` | 否 | ./logs | 日志目录 |
| `GIN_MODE` | 否 | debug | release/debug/test |
| `DEBUG` | 否 | false | 调试模式 |
| `NODE_TYPE` | 否 | master | master/slave（多节点） |
| `SQL_DSN` | 否 | 空 | MySQL/PostgreSQL 连接（替代 SQLite） |
| `REDIS_CONN_STRING` | 否 | 空 | Redis（性能提升） |
| `SYNC_FREQUENCY` | 否 | 60 | 缓存同步频率（秒） |
| `MEMORY_CACHE_ENABLED` | 否 | false | 内存缓存（单实例开启） |
| `GLOBAL_API_RATE_LIMIT` | 否 | 360 | 全局 API 速率（次/180秒） |
| `GLOBAL_WEB_RATE_LIMIT` | 否 | 120 | 全局 Web 速率 |
| `MAX_REQUEST_BODY_MB` | 否 | 128 | 请求体最大（MB） |
| `STREAMING_TIMEOUT` | 否 | 300 | 流式超时（秒） |
| `TRUSTED_PROXIES` | 否 | 默认私网 | APP 内嵌可设 `none` 严格模式 |

完整列表：`common/init.go:InitEnv()`（约 60 个环境变量）

## 5. 首次启动初始化

New API 启动时若检测到未初始化（`setups` 表为空），会自动进入「安装向导」状态：
- 首次访问 `http://127.0.0.1:13000/` 自动重定向到 `/setup`
- 提交 `POST /api/setup` 创建 root 账号
- 之后所有 `/api/*` 才能正常工作

**APP 设计要点**：首次启动时检测 `/api/setup` 返回 `{ "initialized": false }`，自动打开 WebView 引导用户完成初始化。

## 6. 数据备份与迁移

- **备份**：整个 `data/` 目录（`new-api.db` + 日志）拷走即可
- **跨设备迁移**：拷过去修改 `SQLITE_PATH` 即可
- **跨版本升级**：程序停止 → 替换二进制 → 启动（数据库自动迁移）

## 7. 性能与资源（实测参考）

- 二进制大小：约 **30-50 MB**（包含 embed 前端）
- 内存占用：闲置约 **80-150 MB**
- 启动时间：约 **2-3 秒**
- SQLite 数据库：1 万用户约 50 MB
- 适合在 **中高端安卓机**（4GB+ RAM）上运行

## 8. 安卓特有问题与对策

| 问题 | 对策 |
|---|---|
| Doze 模式杀后台 | APP 前台时启动服务，绑定前台通知 |
| 电池优化 | 加 `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` 权限 |
| 进程被杀 | 用 `START_STICKY` 启动服务 |
| 没有 WebView 也能用 API | UI 是 native 的，二进制仅做 API server |
| 跨域 | Go 二进制已开启 CORS，APP 调 native HTTP 不涉及 |
| 二进制文件权限 | `chmod 755` 一下 |
| ARM64 vs x86_64 | 优先 ARM64（99% 设备）；可选提供 x86_64 给 Chromebook |