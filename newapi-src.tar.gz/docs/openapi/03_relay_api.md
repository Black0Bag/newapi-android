# AI 中继/调用 API（/v1/* 兼容 OpenAI/Claude/Gemini）

> 来源：`docs/openapi/relay.json`（35 个接口）+ `router/relay-router.go`
> 鉴权：`Authorization: Bearer sk-xxx`（API Key，来自 `/api/token/`）
> 兼容：也支持 `x-api-key`（Anthropic）和 `x-goog-api-key`/`?key=`（Gemini）

## 1. 基础模型查询

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/v1/models` | 列出可用模型（OpenAI/Claude/Gemini 头部自动识别） |
| GET | `/v1/models/{model}` | 获取单个模型详情 |
| GET | `/v1beta/models` | Gemini 风格模型列表 |
| GET | `/v1beta/openai/models` | Gemini-OpenAI 兼容 |

## 2. 聊天（Chat Completions）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/chat/completions` | OpenAI 聊天主接口（流式/非流式） |
| POST | `/v1/completions` | 旧版 completions |
| POST | `/pg/chat/completions` | Playground 接口（UserAuth 而非 TokenAuth） |

## 3. OpenAI Responses API

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/responses` | OpenAI Responses 格式（实验） |
| POST | `/v1/responses/compact` | 压缩对话 |

## 4. Anthropic Claude

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/messages` | Claude Messages API |

## 5. Google Gemini

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1beta/models/{model}:generateContent` | Gemini 风格调用 |
| POST | `/v1/models/*path` | Gemini 兼容路径转发 |

## 6. 图像

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/images/generations` | 文生图 |
| POST | `/v1/images/edits` | 图像编辑 |
| POST | `/v1/images/variations` | 图像变体（**未实现**） |

## 7. 视频

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/videos` | OpenAI 视频创建 |
| GET | `/v1/videos/{task_id}` | 获取视频任务状态 |
| GET | `/v1/videos/{task_id}/content` | 获取视频内容 |
| POST | `/v1/video/generations` | Sora 风格视频 |
| GET | `/v1/video/generations/{task_id}` | Sora 风格查询 |
| POST | `/v1/videos/{video_id}/remix` | 视频重混 |
| POST | `/kling/v1/videos/text2video` | 可灵文生视频 |
| GET | `/kling/v1/videos/text2video/{task_id}` | 可灵文生视频状态 |
| POST | `/kling/v1/videos/image2video` | 可灵图生视频 |
| GET | `/kling/v1/videos/image2video/{task_id}` | 可灵图生视频状态 |
| POST | `/jimeng/` | 即梦视频 |

## 8. 音频

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/audio/transcriptions` | 音频转录（whisper） |
| POST | `/v1/audio/translations` | 音频翻译 |
| POST | `/v1/audio/speech` | 文本转语音 |

## 9. 嵌入/重排/审核

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/embeddings` | 文本嵌入 |
| POST | `/v1/engines/{model}/embeddings` | Gemini 嵌入（兼容） |
| POST | `/v1/rerank` | 文档重排序 |
| POST | `/v1/moderations` | 内容审核 |

## 10. 实时

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/v1/realtime` | WebSocket（OpenAI Realtime 协议） |

## 11. Midjourney

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/mj/image/{id}` | 获取图片资源 |
| POST | `/mj/submit/action` | 提交动作（升级/变化等） |
| POST | `/mj/submit/shorten` | 提交 shorten |
| POST | `/mj/submit/modal` | 提交 modal |
| POST | `/mj/submit/imagine` | 提交 imagine |
| POST | `/mj/submit/change` | 提交 change |
| POST | `/mj/submit/simple-change` | 简单变化 |
| POST | `/mj/submit/describe` | 提交 describe |
| POST | `/mj/submit/blend` | 提交 blend |
| POST | `/mj/submit/edits` | 提交编辑 |
| POST | `/mj/submit/video` | 提交视频 |
| GET | `/mj/task/{id}/fetch` | 获取任务状态 |
| GET | `/mj/task/{id}/image-seed` | 获取图片种子 |
| POST | `/mj/task/list-by-condition` | 条件列表 |
| POST | `/mj/insight-face/swap` | 人脸交换 |
| POST | `/mj/submit/upload-discord-images` | 上传 Discord 图片 |
| POST | `/{mode}/mj/...` | 同上，带 mode 前缀 |

> 还有 alpha 搜索接口（Codex 独立）：`POST /v1/alpha/search`

## 12. 任务中心（通用 TokenAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/tasks/{key}` | 提交任务 |
| GET | `/v1/tasks/{key}` | 获取任务 |
| GET | `/v1/tasks/{key}/artifacts` | 工件列表 |
| GET | `/v1/tasks/{key}/artifacts/{artifact_key}/content` | 工件内容 |
| HEAD | `/v1/tasks/{key}/artifacts/{artifact_key}/content` | HEAD 形式 |

## 13. 旧版/兼容 Billing Dashboard（TokenAuth）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/dashboard/billing/subscription` | 旧版订阅查询 |
| GET | `/v1/dashboard/billing/subscription` | 同上，v1 路径 |
| GET | `/dashboard/billing/usage` | 旧版用量查询 |
| GET | `/v1/dashboard/billing/usage` | 同上，v1 路径 |

## 14. 旧版/兼容（TokenAuth，OpenAI 风格）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/v1/files` | 列出文件（**未实现**） |
| POST | `/v1/files` | 上传文件（**未实现**） |
| GET | `/v1/files/{file_id}` | 获取文件（**未实现**） |
| DELETE | `/v1/files/{file_id}` | 删除文件（**未实现**） |
| GET | `/v1/files/{file_id}/content` | 获取文件内容（**未实现**） |
| GET | `/v1/fine-tunes` | 微调列表（**未实现**） |
| POST | `/v1/fine-tunes` | 创建微调（**未实现**） |
| GET | `/v1/fine-tunes/{fine_tune_id}` | 微调详情（**未实现**） |
| POST | `/v1/fine-tunes/{fine_tune_id}/cancel` | 取消微调（**未实现**） |
| GET | `/v1/fine-tunes/{fine_tune_id}/events` | 微调事件（**未实现**） |

---

## 实战要点（APP 对接）

1. **请求格式**直接用 OpenAI/Claude/Gemini 官方 SDK 即可，无需任何特殊处理。New API 是**上游代理** + **格式转换器**。
2. **流式响应**：SSE（`text/event-stream`），APP 用 OkHttp + EventSource 风格实现。
3. **错误格式**：完全遵循 OpenAI 错误格式：
   ```json
   { "error": { "message": "...", "type": "...", "code": "..." } }
   ```
4. **重试建议**：429/5xx 自动重试，401 重新登录。503 时降级到其他 channel（New API 内部已做）。
5. **/pg 路径**是 Playground 接口（`UserAuth`），给登录用户从 Web UI 调用模型用，APP 一般不用。